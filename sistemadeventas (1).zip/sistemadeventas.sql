-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 10-12-2024 a las 03:04:28
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `sistemadeventas`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `clientes`
--

CREATE TABLE `clientes` (
  `id` int(11) NOT NULL,
  `dni` int(20) NOT NULL,
  `nombre` varchar(150) NOT NULL,
  `telefono` varchar(15) NOT NULL,
  `direccion` varchar(200) NOT NULL,
  `razon` varchar(200) NOT NULL,
  `fecha` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `clientes`
--

INSERT INTO `clientes` (`id`, `dni`, `nombre`, `telefono`, `direccion`, `razon`, `fecha`) VALUES
(2, 22222, 'jheffff', '1223123', 'fzfdsfs', 'gddfdsf', '2024-10-31 13:13:11'),
(3, 67543245, 'Yair', '978654325', 'La Molina', 'Lima', '2024-10-31 13:45:04'),
(4, 72345698, 'jheffry', '1223123', 'San Isidro', 'Lima', '2024-10-31 13:46:00'),
(5, 22222, 'jheffff', '1223123', 'fzfdsfs', 'ddd', '2024-10-31 13:46:43'),
(6, 71259210, 'jhefry', '1223123', 'fzfdsfs', 'vendedor', '2024-12-09 02:24:33');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `config`
--

CREATE TABLE `config` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `ruc` varchar(20) NOT NULL,
  `telefono` int(15) NOT NULL,
  `direccion` varchar(200) NOT NULL,
  `razon` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detalle`
--

CREATE TABLE `detalle` (
  `id` int(11) NOT NULL,
  `cod_pro` int(11) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `precio` decimal(10,2) NOT NULL,
  `id_venta` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `detalle`
--

INSERT INTO `detalle` (`id`, `cod_pro`, `cantidad`, `precio`, `id_venta`) VALUES
(1, 1, 1, 2.00, 0),
(2, 1, 1, 2.00, 0),
(3, 1, 1, 2.00, 0),
(4, 2, 2, 18.00, 0),
(5, 2, 2, 18.00, 0),
(6, 1, 2, 2.00, 0),
(7, 1, 1, 2.00, 0),
(8, 2, 1, 18.00, 0),
(9, 1, 1, 2.00, 0),
(10, 2, 3, 18.00, 0),
(11, 1, 2, 2.00, 0),
(12, 2, 1, 18.00, 0),
(13, 2, 5, 18.00, 0),
(14, 1, 6, 2.00, 0),
(15, 1, 2, 2.00, 0),
(16, 2, 3, 18.00, 0),
(17, 1, 2, 2.00, 0),
(18, 2, 2, 18.00, 0),
(19, 1, 2, 2.00, 0),
(20, 2, 3, 18.00, 0),
(21, 1, 2, 2.00, 0),
(22, 2, 2, 18.00, 0),
(23, 2, 2, 18.00, 0),
(24, 1, 5, 2.00, 0),
(25, 1, 2, 2.00, 0),
(26, 2, 1, 18.00, 0),
(27, 1, 2, 2.00, 0),
(28, 2, 2, 18.00, 0),
(29, 2, 2, 18.00, 0),
(30, 1, 3, 2.00, 0),
(31, 2, 2, 18.00, 0),
(32, 1, 3, 2.00, 0),
(33, 2, 2, 18.00, 0),
(34, 1, 3, 2.00, 0),
(35, 2, 2, 18.00, 0),
(36, 1, 3, 2.00, 0),
(37, 1, 2, 2.00, 0),
(38, 2, 3, 18.00, 0),
(39, 2, 2, 18.00, 0),
(40, 1, 2, 2.00, 0),
(41, 3, 2, 35.00, 0),
(42, 2, 1, 18.00, 0),
(43, 1, 3, 2.00, 0),
(44, 2, 3, 18.00, 0),
(45, 3, 2, 35.00, 0),
(46, 3, 5, 35.00, 0),
(47, 1, 6, 2.00, 0),
(48, 2, 12, 18.00, 0),
(49, 3, 4, 35.00, 0),
(50, 1, 6, 2.00, 0),
(51, 1, 3, 2.00, 0),
(52, 2, 5, 18.00, 0),
(53, 3, 5, 35.00, 0),
(54, 1, 8, 2.00, 0),
(55, 2, 2, 18.00, 0),
(56, 3, 5, 35.00, 0),
(57, 2, 2, 18.00, 0),
(58, 2, 5, 18.00, 0),
(59, 3, 9, 35.00, 0),
(60, 1, 2, 2.00, 1),
(61, 3, 3, 35.00, 1),
(62, 2, 2, 18.00, 1),
(63, 3, 1, 35.00, 2),
(64, 2, 4, 18.00, 2),
(65, 1, 4, 2.00, 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

CREATE TABLE `productos` (
  `id` int(11) NOT NULL,
  `codigo` varchar(100) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `proveedor` varchar(100) NOT NULL,
  `stock` int(11) NOT NULL,
  `precio` decimal(10,2) NOT NULL,
  `fecha` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `productos`
--

INSERT INTO `productos` (`id`, `codigo`, `nombre`, `proveedor`, `stock`, `precio`, `fecha`) VALUES
(1, '1', 'Ron', 'Ron Sac', 68, 2.00, '2024-10-31 13:04:44'),
(2, '2', 'Vino', 'Jheffry Sac', 64, 18.00, '2024-12-09 02:18:49'),
(3, '3', 'Whisky', 'Jheffry Sac', 64, 35.00, '2024-12-09 03:52:41'),
(4, '4', 'Cerveza', 'jheffry', 100, 7.00, '2024-12-09 13:20:32');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `proveedor`
--

CREATE TABLE `proveedor` (
  `id` int(11) NOT NULL,
  `ruc` int(20) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `telefono` int(15) NOT NULL,
  `direccion` varchar(200) NOT NULL,
  `razon` varchar(200) NOT NULL,
  `fecha` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `proveedor`
--

INSERT INTO `proveedor` (`id`, `ruc`, `nombre`, `telefono`, `direccion`, `razon`, `fecha`) VALUES
(1, 1111, 'ffrfr', 321321, 'fdfdfdf', '', '2024-10-30 22:13:33'),
(2, 1111, 'ffrfr', 321321, 'fdfdfdf', '', '2024-10-30 22:13:35'),
(3, 1111, 'ffrfr', 321321, 'fdfdfdf', '', '2024-10-30 22:13:35'),
(4, 1111, 'ffrfr', 321321, 'fdfdfdf', '', '2024-10-30 22:13:35'),
(5, 1111, 'ffrfr', 321321, 'fdfdfdf', '', '2024-10-30 22:13:36'),
(6, 1111, 'ffrfr', 321321, 'fdfdfdf', '', '2024-10-30 22:13:36'),
(7, 1111, 'Peres', 321321, 'fdfdfdf', 'wwdw', '2024-10-30 22:13:36'),
(8, 1111, 'juan', 321321, 'lote 7', 'gggg', '2024-10-30 22:13:36'),
(18, 939299, 'jheffry', 996777315, 'ucv 21 ', 'Gerente', '2024-10-31 00:06:12');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE `usuario` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `correo` varchar(100) NOT NULL,
  `pass` varchar(100) NOT NULL,
  `rol` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`id`, `nombre`, `correo`, `pass`, `rol`) VALUES
(1, 'Jheffry', 'Jheffry@hotmail.com', '12345', 'Administrador'),
(2, 'admin', 'admin@hotmail.com', '123', 'Administrador');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ventas`
--

CREATE TABLE `ventas` (
  `id` int(11) NOT NULL,
  `cliente` varchar(100) NOT NULL,
  `Vendedor` varchar(100) NOT NULL,
  `total` decimal(10,2) NOT NULL,
  `fecha` varchar(200) NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `ventas`
--

INSERT INTO `ventas` (`id`, `cliente`, `Vendedor`, `total`, `fecha`) VALUES
(1, 'jheffff', 'Jheffry', 145.00, '09/12/2024'),
(2, 'jhefry', 'Jheffry', 115.00, '09/12/2024');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `clientes`
--
ALTER TABLE `clientes`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `config`
--
ALTER TABLE `config`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `detalle`
--
ALTER TABLE `detalle`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `productos`
--
ALTER TABLE `productos`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `proveedor`
--
ALTER TABLE `proveedor`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `ventas`
--
ALTER TABLE `ventas`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `clientes`
--
ALTER TABLE `clientes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `config`
--
ALTER TABLE `config`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `detalle`
--
ALTER TABLE `detalle`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=66;

--
-- AUTO_INCREMENT de la tabla `productos`
--
ALTER TABLE `productos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `proveedor`
--
ALTER TABLE `proveedor`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT de la tabla `usuario`
--
ALTER TABLE `usuario`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `ventas`
--
ALTER TABLE `ventas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
