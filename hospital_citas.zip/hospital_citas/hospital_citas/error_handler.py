try:
    import traceback
    from datetime import datetime
    from flask import render_template, request
except ImportError as e:
    print(f"Error al importar módulos de manejo de errores: {e}")
    raise
except Exception as e:
    print(f"Error inesperado en manejo de errores: {e}")
    raise

class ErrorHandler:
    """Clase para manejar errores de manera centralizada"""
    
    @staticmethod
    def handle_database_error(error, operation=""):
        """Maneja errores de base de datos"""
        try:
            error_msg = f"Error de base de datos en {operation}: {str(error)}"
            print(error_msg)
            return error_msg
        except Exception as e:
            print(f"Error al manejar error de base de datos: {e}")
            return "Error de base de datos"

    @staticmethod
    def handle_validation_error(error, field=""):
        """Maneja errores de validación"""
        try:
            error_msg = f"Error de validación en {field}: {str(error)}"
            print(error_msg)
            return error_msg
        except Exception as e:
            print(f"Error al manejar error de validación: {e}")
            return "Error de validación"

    @staticmethod
    def handle_email_error(error):
        """Maneja errores de email"""
        try:
            error_msg = f"Error de email: {str(error)}"
            print(error_msg)
            return error_msg
        except Exception as e:
            print(f"Error al manejar error de email: {e}")
            return "Error de email"

    @staticmethod
    def handle_pdf_error(error):
        """Maneja errores de generación de PDF"""
        try:
            error_msg = f"Error al generar PDF: {str(error)}"
            print(error_msg)
            return error_msg
        except Exception as e:
            print(f"Error al manejar error de PDF: {e}")
            return "Error al generar PDF"

    @staticmethod
    def handle_auth_error(error):
        """Maneja errores de autenticación"""
        try:
            error_msg = f"Error de autenticación: {str(error)}"
            print(error_msg)
            return error_msg
        except Exception as e:
            print(f"Error al manejar error de autenticación: {e}")
            return "Error de autenticación"

    @staticmethod
    def log_error(error, context=""):
        """Registra errores en archivo de log"""
        try:
            timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            error_info = {
                'timestamp': timestamp,
                'error': str(error),
                'context': context,
                'traceback': traceback.format_exc()
            }
            
            log_entry = f"[{timestamp}] ERROR en {context}: {str(error)}\n"
            log_entry += f"Traceback: {error_info['traceback']}\n"
            
            with open('hospital_app.log', 'a', encoding='utf-8') as log_file:
                log_file.write(log_entry)
                
        except Exception as e:
            print(f"Error al escribir en log: {e}")

    @staticmethod
    def handle_generic_error(error, context=""):
        """Maneja errores genéricos"""
        try:
            error_msg = f"Error inesperado en {context}: {str(error)}"
            print(error_msg)
            ErrorHandler.log_error(error, context)
            return error_msg
        except Exception as e:
            print(f"Error al manejar error genérico: {e}")
            return "Error interno del servidor"

def safe_execute(func, *args, **kwargs):
    """Ejecuta una función de manera segura con manejo de excepciones"""
    try:
        return func(*args, **kwargs)
    except Exception as e:
        ErrorHandler.log_error(e, f"Función: {func.__name__}")
        return None

def validate_request_data(data, required_fields):
    """Valida datos de request con manejo de excepciones"""
    try:
        missing_fields = []
        for field in required_fields:
            if field not in data or not data[field]:
                missing_fields.append(field)
        
        if missing_fields:
            return False, f"Campos requeridos faltantes: {', '.join(missing_fields)}"
        
        return True, "Datos válidos"
    except Exception as e:
        ErrorHandler.log_error(e, "Validación de datos")
        return False, "Error al validar datos" 