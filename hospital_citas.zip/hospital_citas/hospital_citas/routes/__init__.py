try:
    from .main import main_bp
    from .admin import admin_bp
except ImportError as e:
    print(f"Error al importar blueprints: {e}")
    raise
except Exception as e:
    print(f"Error inesperado al importar rutas: {e}")
    raise 