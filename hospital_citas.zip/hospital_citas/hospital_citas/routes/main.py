try:
    from flask import Blueprint, render_template, request, redirect, session, url_for, send_file, jsonify
    from models import get_db_connection
    from fpdf import FPDF
    from io import BytesIO
    import smtplib
    from email.message import EmailMessage
except ImportError as e:
    print(f"Error al importar módulos en main.py: {e}")
    print("Asegúrate de tener todas las dependencias instaladas")
    raise
except Exception as e:
    print(f"Error inesperado al importar en main.py: {e}")
    raise

main_bp = Blueprint('main', __name__)

@main_bp.route('/')
def inicio():
    try:
        return render_template('inicio.html')
    except Exception as e:
        print(f"Error al cargar página de inicio: {e}")
        return "Error interno del servidor", 500

@main_bp.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        try:
            usuario = request.form['usuario']
            contrasena = request.form['contrasena']
            conn = get_db_connection()
            if conn is None:
                return "Error de conexión con la base de datos"
            
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM administradores WHERE usuario=? AND contrasena=?", (usuario, contrasena))
            admin = cursor.fetchone()
            conn.close()
            if admin:
                session['admin'] = True
                return redirect('/admin')
            else:
                return "Credenciales incorrectas"
        except Exception as e:
            print(f"Error en login: {e}")
            return "Error interno del servidor"
    return render_template('login.html')

@main_bp.route('/registro_paciente', methods=['GET', 'POST'])
def registro_paciente():
    try:
        if request.method == 'POST':
            nombre = request.form['nombre']
            email = request.form['email']
            contrasena = request.form['contrasena']

            conn = get_db_connection()
            if conn is None:
                return "Error al conectar con la base de datos"

            cursor = conn.cursor()

            # Verificar si el email ya está registrado
            cursor.execute("SELECT * FROM usuarios WHERE email = ?", (email,))
            existente = cursor.fetchone()
            if existente:
                conn.close()
                return render_template('registro_paciente.html', error="❌ El correo ya está registrado.")

            # Insertar nuevo usuario
            cursor.execute("INSERT INTO usuarios (nombre, email, contrasena) VALUES (?, ?, ?)",
                           (nombre, email, contrasena))
            conn.commit()
            conn.close()

            return render_template('registro_paciente.html', mensaje="✅ Registro exitoso. ¡Ahora puedes iniciar sesión!")

        return render_template('registro_paciente.html')

    except Exception as e:
        print(f"Error en registro de paciente: {e}")
        return "Error interno del servidor"

@main_bp.route('/logout')
def logout():
    try:
        session.clear()
        return redirect('/')
    except Exception as e:
        print(f"Error al cerrar sesión: {e}")
        return redirect('/')

@main_bp.route('/citas')
def citas():
    try:
        conn = get_db_connection()
        if conn is None:
            return "Error de conexión con la base de datos"
        
        doctores = conn.execute('SELECT * FROM doctores').fetchall()
        conn.close()
        return render_template('citas.html', doctores=doctores, error=None)
    except Exception as e:
        print(f"Error al cargar citas: {e}")
        return render_template('citas.html', doctores=[], error=None)

@main_bp.route('/agendar_cita', methods=['POST'])
def agendar_cita():
    try:
        paciente = request.form['paciente']
        fecha = request.form['fecha']
        hora = request.form['hora']
        doctor_id = request.form['doctor']
        email = request.form['email']
        
        conn = get_db_connection()
        if conn is None:
            return "Error de conexión con la base de datos"
        
        cursor = conn.cursor()
        
        # Verificar si ya existe una cita PENDIENTE para el mismo doctor en la misma fecha y hora
        cursor.execute('''SELECT COUNT(*) FROM citas 
                         WHERE doctor_id = ? AND fecha = ? AND hora = ? AND estado = 'pendiente' ''', 
                      (doctor_id, fecha, hora))
        cita_existente = cursor.fetchone()[0]
        
        if cita_existente > 0:
            conn.close()
            # Obtener información del doctor para mostrar en el mensaje de error
            conn = get_db_connection()
            doctor = conn.execute('SELECT nombre, especialidad FROM doctores WHERE id = ?', (doctor_id,)).fetchone()
            doctores = conn.execute('SELECT * FROM doctores').fetchall()
            conn.close()
            
            mensaje_error = f"❌ Ya existe una cita pendiente para el Dr. {doctor[0]} ({doctor[1]}) el {fecha} a las {hora}. Por favor, selecciona otro horario."
            return render_template('citas.html', 
                                doctores=doctores,
                                error=mensaje_error)
        
        # Si no hay conflicto, proceder con la inserción
        data = (paciente, fecha, hora, doctor_id, email)
        cursor.execute('INSERT INTO citas (paciente, fecha, hora, doctor_id, email) VALUES (?, ?, ?, ?, ?)', data)
        cita_id = cursor.lastrowid
        conn.commit()
        conn.close()
        return redirect(url_for('main.resumen_cita', cita_id=cita_id))
    except Exception as e:
        print(f"Error al agendar cita: {e}")
        return "Error al agendar la cita"

@main_bp.route('/resumen_cita/<int:cita_id>')
def resumen_cita(cita_id):
    try:
        conn = get_db_connection()
        if conn is None:
            return "Error de conexión con la base de datos"
        
        cita = conn.execute('''SELECT citas.id, paciente, fecha, hora, doctores.nombre, doctores.especialidad, email 
                              FROM citas JOIN doctores ON citas.doctor_id = doctores.id WHERE citas.id=?''', (cita_id,)).fetchone()
        conn.close()
        return render_template('resumen_cita.html', cita=cita)
    except Exception as e:
        print(f"Error al obtener resumen de cita: {e}")
        return "Error al cargar el resumen de la cita"

@main_bp.route('/descargar_pdf/<int:cita_id>')
def descargar_pdf(cita_id):
    try:
        from math import pi
        from datetime import datetime
        from fpdf import FPDF
        def rounded_rect(pdf, x, y, w, h, r=3, style='D'):
            # Dibuja un rectángulo con esquinas redondeadas
            k = pdf.k
            hp = pdf.h
            op = {'F': 'f', 'FD': 'B', 'DF': 'B'}.get(style, 'S')
            MyArc = 4/3 * (2**0.5 - 1) * r
            pdf._out('%.2f %.2f m' % ((x+r)*k, (hp-y)*k))
            pdf._out('%.2f %.2f l' % ((x+w-r)*k, (hp-y)*k))
            pdf._Arc(pdf, x+w-r+MyArc, y, x+w, y+ r-MyArc, x+w, y+r)
            pdf._out('%.2f %.2f l' % ((x+w)*k, (hp-y-h+r)*k))
            pdf._Arc(pdf, x+w, y+h-r+MyArc, x+w-r+MyArc, y+h, x+w-r, y+h)
            pdf._out('%.2f %.2f l' % ((x+r)*k, (hp-y-h)*k))
            pdf._Arc(pdf, x+r-MyArc, y+h, x, y+h-r+MyArc, x, y+h-r)
            pdf._out('%.2f %.2f l' % ((x)*k, (hp-y+r)*k))
            pdf._Arc(pdf, x, y+r-MyArc, x+r-MyArc, y, x+r, y)
            pdf._out(op)
        def _Arc(pdf, x1, y1, x2, y2, x3, y3):
            h = pdf.h
            pdf._out('%.2f %.2f %.2f %.2f %.2f %.2f c' % (x1*pdf.k, (h-y1)*pdf.k, x2*pdf.k, (h-y2)*pdf.k, x3*pdf.k, (h-y3)*pdf.k))
        FPDF._Arc = _Arc
        FPDF.rounded_rect = rounded_rect

        conn = get_db_connection()
        if conn is None:
            return "Error de conexión con la base de datos"
        
        cita = conn.execute('''SELECT citas.id, paciente, fecha, hora, doctores.nombre, doctores.especialidad, email, citas.diagnostico, citas.receta 
                               FROM citas JOIN doctores ON citas.doctor_id = doctores.id WHERE citas.id=?''', (cita_id,)).fetchone()
        conn.close()

        pdf = FPDF()
        pdf.add_page()
        pdf.set_auto_page_break(auto=True, margin=15)

        # Logo (opcional, dejar espacio)
        pdf.set_font("Arial", 'B', 16)
        pdf.cell(40, 20, "", 0, 0)  # Espacio para logo
        pdf.cell(110, 20, "COMPROBANTE DE CITA", 0, 0, 'C')
        pdf.set_font("Arial", '', 12)
        pdf.cell(0, 20, f"Cita Nro. C{cita[0]:06d}", 0, 1, 'R')
        pdf.ln(4)

        # Recuadro de datos del paciente
        x1 = pdf.get_x()
        y1 = pdf.get_y()
        w = 190
        h = 22
        pdf.set_draw_color(180, 180, 180)
        pdf.set_fill_color(245, 245, 245)
        pdf.rect(x1, y1, w, h, 'D')
        pdf.set_xy(x1+2, y1+2)
        pdf.set_font("Arial", '', 11)
        pdf.cell(95, 8, f"Paciente: {cita[1]}", 0, 0)
        pdf.cell(50, 8, f"Email: {cita[6] if cita[6] else '-'}", 0, 0)
        pdf.cell(0, 8, f"Fecha: {cita[2]}", 0, 1)
        pdf.cell(95, 8, f"Hora: {cita[3]}", 0, 0)
        pdf.cell(50, 8, f"Doctor: {cita[4]}", 0, 0)
        pdf.cell(0, 8, f"Especialidad: {cita[5]}", 0, 1)
        pdf.ln(10)

        # Diagnóstico en recuadro
        if cita[7]:
            x2 = pdf.get_x()
            y2 = pdf.get_y()
            w2 = 190
            h2 = 16 + (pdf.get_string_width(cita[7]) // 120) * 8
            pdf.rect(x2, y2, w2, h2, 'D')
            pdf.set_xy(x2+2, y2+2)
            pdf.set_font("Arial", 'B', 11)
            pdf.cell(0, 7, "Diagnóstico", 0, 1)
            pdf.set_font("Arial", '', 11)
            pdf.multi_cell(0, 7, cita[7], 0, 1)
            pdf.ln(10)

        # Receta en recuadro
        if cita[8]:
            x3 = pdf.get_x()
            y3 = pdf.get_y()
            w3 = 190
            h3 = 16 + (pdf.get_string_width(cita[8]) // 120) * 8
            pdf.rect(x3, y3, w3, h3, 'D')
            pdf.set_xy(x3+2, y3+2)
            pdf.set_font("Arial", 'B', 11)
            pdf.cell(0, 7, "Receta", 0, 1)
            pdf.set_font("Arial", '', 11)
            pdf.multi_cell(0, 7, cita[8], 0, 1)
            pdf.ln(10)

        # Pie de página
        pdf.set_y(-30)
        pdf.set_font("Arial", '', 9)
        fecha_imp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        pdf.cell(0, 8, f"Cita Nro. C{cita[0]:06d} - Fecha Imp: {fecha_imp} - Página 1 de 1", 0, 1, 'C')

        buffer = BytesIO()
        pdf_bytes = pdf.output(dest='S').encode('latin1')
        buffer.write(pdf_bytes)
        buffer.seek(0)

        return send_file(buffer, as_attachment=True, download_name=f'cita_C{cita[0]:06d}.pdf', mimetype='application/pdf')
    except Exception as e:
        print(f"Error al generar PDF: {e}")
        return "Error al generar el PDF"

@main_bp.route('/enviar_cita_email/<int:cita_id>')
def enviar_cita_email(cita_id):
    try:
        conn = get_db_connection()
        if conn is None:
            return "Error de conexión con la base de datos"
        
        cita = conn.execute('''SELECT paciente, fecha, hora, doctores.nombre, doctores.especialidad, email 
                               FROM citas JOIN doctores ON citas.doctor_id = doctores.id WHERE citas.id=?''', (cita_id,)).fetchone()
        conn.close()
        if not cita or not cita[5]:
            return "Email no encontrado"

        msg = EmailMessage()
        msg['Subject'] = '🩺 Confirmación de tu Cita Médica'
        msg['From'] = 'fabrize18lion@gmail.com'
        msg['To'] = cita[5]
        msg.set_content(f"Hola {cita[0]},\n\nTu cita con el doctor {cita[3]} ({cita[4]}) ha sido agendada con éxito.\n\n• Fecha: {cita[1]}\n• Hora: {cita[2]}\n\nGracias por confiar en nosotros.\n\nCentro Médico UTP")

        try:
            with smtplib.SMTP_SSL('smtp.gmail.com', 465) as smtp:
                smtp.login('fabrize18lion@gmail.com', 'iuci qioo zgfe ugxp')
                smtp.send_message(msg)
            return "✅ Correo enviado con éxito al paciente"
        except Exception as e:
            print(f"Error al enviar email: {e}")
            return f"❌ Error al enviar correo: {e}"
    except Exception as e:
        print(f"Error al enviar email: {e}")
        return "❌ Error interno del servidor"

@main_bp.route('/cita_detalle/<int:cita_id>')
def cita_detalle(cita_id):
    try:
        conn = get_db_connection()
        if conn is None:
            return "Error de conexión con la base de datos"
        
        cita = conn.execute('''SELECT citas.id, paciente, fecha, hora, doctores.nombre, doctores.especialidad, email, citas.estado, diagnostico, receta
                              FROM citas JOIN doctores ON citas.doctor_id = doctores.id WHERE citas.id=?''', (cita_id,)).fetchone()
        conn.close()
        
        if not cita:
            return "Cita no encontrada", 404
            
        return render_template('citas_detalle.html', cita=cita)
    except Exception as e:
        print(f"Error al obtener detalle de cita: {e}")
        return "Error al cargar el detalle de la cita"

@main_bp.route('/buscar_cita', methods=['GET', 'POST'])
def buscar_cita():
    try:
        if request.method == 'POST':
            paciente = request.form.get('paciente', '')
            email = request.form.get('email', '')
            
            conn = get_db_connection()
            if conn is None:
                return "Error de conexión con la base de datos"
            
            # Buscar citas por paciente o email
            if paciente and email:
                citas = conn.execute('''SELECT citas.id, paciente, fecha, hora, doctores.nombre, doctores.especialidad, email, citas.estado
                                       FROM citas JOIN doctores ON citas.doctor_id = doctores.id 
                                       WHERE paciente LIKE ? AND email LIKE ?''', 
                                    (f'%{paciente}%', f'%{email}%')).fetchall()
            elif paciente:
                citas = conn.execute('''SELECT citas.id, paciente, fecha, hora, doctores.nombre, doctores.especialidad, email, citas.estado
                                       FROM citas JOIN doctores ON citas.doctor_id = doctores.id 
                                       WHERE paciente LIKE ?''', 
                                    (f'%{paciente}%',)).fetchall()
            elif email:
                citas = conn.execute('''SELECT citas.id, paciente, fecha, hora, doctores.nombre, doctores.especialidad, email, citas.estado
                                       FROM citas JOIN doctores ON citas.doctor_id = doctores.id 
                                       WHERE email LIKE ?''', 
                                    (f'%{email}%',)).fetchall()
            else:
                citas = []
            
            conn.close()
            return render_template('buscar_cita.html', citas=citas, paciente=paciente, email=email)
        
        return render_template('buscar_cita.html', citas=[], paciente='', email='')
    except Exception as e:
        print(f"Error al buscar citas: {e}")
        return "Error al buscar citas"

def rounded_rect(self, x, y, w, h, r, style='D'):
    """Dibuja un rectángulo con bordes redondeados"""
    # Líneas horizontales
    self.line(x+r, y, x+w-r, y)
    self.line(x+r, y+h, x+w-r, y+h)
    # Líneas verticales
    self.line(x, y+r, x, y+h-r)
    self.line(x+w, y+r, x+w, y+h-r)
    # Esquinas redondeadas usando _Arc
    self._Arc(x, y, r*2, r*2, 90, 180)
    self._Arc(x+w-r*2, y, r*2, r*2, 0, 90)
    self._Arc(x+w-r*2, y+h-r*2, r*2, r*2, 270, 360)
    self._Arc(x, y+h-r*2, r*2, r*2, 180, 270)

def generate_pdf(self, cita):
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Arial", 'B', 16)
    pdf.cell(0, 10, "COMPROBANTE DE CITA MÉDICA", 0, 1, 'C')
    pdf.ln(5)

    # Recuadro de datos del paciente
    x1 = pdf.get_x() + 5  # Padding izquierdo
    y1 = pdf.get_y() + 5   # Padding superior
    w = 180  # Ancho reducido para padding
    h = 22
    pdf.set_draw_color(0, 0, 0)  # Negro
    pdf.set_fill_color(245, 245, 245)
    pdf.rounded_rect(x1, y1, w, h, 3, 'D')
    pdf.set_xy(x1+5, y1+5)  # Padding interno
    pdf.set_font("Arial", '', 11)
    pdf.cell(90, 8, f"Paciente: {cita[1]}", 0, 0)
    pdf.cell(45, 8, f"Email: {cita[6] if cita[6] else '-'}", 0, 0)
    pdf.cell(0, 8, f"Fecha: {cita[2]}", 0, 1)
    pdf.cell(90, 8, f"Hora: {cita[3]}", 0, 0)
    pdf.cell(45, 8, f"Doctor: {cita[4]}", 0, 0)
    pdf.cell(0, 8, f"Especialidad: {cita[5]}", 0, 1)
    pdf.ln(15)  # Más espacio

    # Diagnóstico en recuadro
    if cita[7]:
        x2 = pdf.get_x() + 5
        y2 = pdf.get_y() + 5
        w2 = 180
        h2 = 20 + (pdf.get_string_width(cita[7]) // 120) * 8
        pdf.rounded_rect(x2, y2, w2, h2, 3, 'D')
        pdf.set_xy(x2+5, y2+5)
        pdf.set_font("Arial", 'B', 11)
        pdf.cell(0, 7, "Diagnóstico", 0, 1)
        pdf.set_font("Arial", '', 11)
        pdf.multi_cell(0, 7, cita[7], 0, 1)
        pdf.ln(15)

    # Receta en recuadro
    if cita[8]:
        x3 = pdf.get_x() + 5
        y3 = pdf.get_y() + 5
        w3 = 180
        h3 = 20 + (pdf.get_string_width(cita[8]) // 120) * 8
        pdf.rounded_rect(x3, y3, w3, h3, 3, 'D')
        pdf.set_xy(x3+5, y3+5)
        pdf.set_font("Arial", 'B', 11)
        pdf.cell(0, 7, "Receta", 0, 1)
        pdf.set_font("Arial", '', 11)
        pdf.multi_cell(0, 7, cita[8], 0, 1)
        pdf.ln(15) 
@main_bp.route('/get_doctores/<especialidad>')
def get_doctores(especialidad):
    try:
        conn = get_db_connection()
        if conn is None:
            return jsonify([])

        cursor = conn.cursor()
        cursor.execute("SELECT id, nombre FROM doctores WHERE especialidad = ?", (especialidad,))
        resultados = cursor.fetchall()
        conn.close()

        doctores = [{"id": row[0], "nombre": row[1]} for row in resultados]
        return jsonify(doctores)

    except Exception as e:
        print(f"Error al obtener doctores: {e}")
        return jsonify([])
@main_bp.route('/login_paciente', methods=['GET', 'POST'])
def login_paciente():
    try:
        if request.method == 'POST':
            email = request.form['email']
            contrasena = request.form['contrasena']

            conn = get_db_connection()
            if conn is None:
                return "Error al conectar con la base de datos"

            cursor = conn.cursor()
            cursor.execute("SELECT * FROM usuarios WHERE email = ? AND contrasena = ?", (email, contrasena))
            paciente = cursor.fetchone()
            conn.close()

            if paciente:
                session['paciente_id'] = paciente['id']
                session['paciente_nombre'] = paciente['nombre']
                return redirect('/tablero_paciente')
            else:
                return render_template('login_paciente.html', error="❌ Correo o contraseña incorrectos")

        return render_template('login_paciente.html')

    except Exception as e:
        print(f"Error en login de paciente: {e}")
        return "Error interno del servidor"
@main_bp.route('/mis_citas')
def mis_citas():
    try:
        if 'paciente_id' not in session:
            return redirect('/login_paciente')  # Si no ha iniciado sesión

        conn = get_db_connection()
        if conn is None:
            return "Error de conexión con la base de datos"

        cursor = conn.cursor()
        # Buscar las citas por el ID del paciente (alternativa: usar su email)
        paciente_nombre = session['paciente_nombre']
        citas = cursor.execute('''
            SELECT citas.id, paciente, fecha, hora, doctores.nombre AS doctor, doctores.especialidad, estado, diagnostico, receta
            FROM citas
            JOIN doctores ON citas.doctor_id = doctores.id
            WHERE paciente = ?
            ORDER BY fecha DESC
        ''', (paciente_nombre,)).fetchall()

        conn.close()

        return render_template('mis_citas.html', citas=citas, nombre=paciente_nombre)

    except Exception as e:
        print(f"Error al cargar citas del paciente: {e}")
        return "Error al cargar las citas"
@main_bp.route('/logout_paciente')
def logout_paciente():
    session.pop('paciente_id', None)
    session.pop('paciente_nombre', None)
    return redirect('/')
@main_bp.route('/tablero_paciente')
def tablero_paciente():
    if 'paciente_id' not in session:
        return redirect('/login_paciente')
    return render_template('tablero_paciente.html')