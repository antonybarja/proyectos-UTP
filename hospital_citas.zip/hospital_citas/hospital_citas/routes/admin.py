try:
    from flask import Blueprint, render_template, request, redirect, session
    from models import get_db_connection
except ImportError as e:
    print(f"Error al importar módulos en admin.py: {e}")
    print("Asegúrate de tener todas las dependencias instaladas")
    raise
except Exception as e:
    print(f"Error inesperado al importar en admin.py: {e}")
    raise

admin_bp = Blueprint('admin', __name__)

@admin_bp.route('/admin')
def admin():
    try:
        if not session.get('admin'):
            return redirect('/login')
        conn = get_db_connection()
        if conn is None:
            return "Error de conexión con la base de datos"
        
        doctores = conn.execute('SELECT * FROM doctores').fetchall()
        conn.close()
        return render_template('admin.html', doctores=doctores)
    except Exception as e:
        print(f"Error en admin: {e}")
        return "Error interno del servidor"

@admin_bp.route('/agregar_doctor', methods=['POST'])
def agregar_doctor():
    try:
        if not session.get('admin'):
            return redirect('/login')
        data = (request.form['nombre'], request.form['especialidad'], request.form['sector'], request.form['horario'])
        conn = get_db_connection()
        if conn is None:
            return "Error de conexión con la base de datos"
        
        conn.execute('INSERT INTO doctores (nombre, especialidad, sector, horario) VALUES (?, ?, ?, ?)', data)
        conn.commit()
        conn.close()
        return redirect('/admin')
    except Exception as e:
        print(f"Error al agregar doctor: {e}")
        return "Error al agregar el doctor"

@admin_bp.route('/editar_doctor/<int:id>', methods=['GET', 'POST'])
def editar_doctor(id):
    try:
        conn = get_db_connection()
        if conn is None:
            return "Error de conexión con la base de datos"
        
        cursor = conn.cursor()
        if request.method == 'POST':
            data = (request.form['nombre'], request.form['especialidad'], request.form['sector'], request.form['horario'], id)
            cursor.execute("UPDATE doctores SET nombre=?, especialidad=?, sector=?, horario=? WHERE id=?", data)
            conn.commit()
            conn.close()
            return redirect('/admin')
        doctor = cursor.execute("SELECT * FROM doctores WHERE id=?", (id,)).fetchone()
        conn.close()
        return render_template('editar_doctor.html', doctor=doctor)
    except Exception as e:
        print(f"Error al editar doctor: {e}")
        return "Error al editar el doctor"

@admin_bp.route('/eliminar_doctor/<int:id>')
def eliminar_doctor(id):
    try:
        if not session.get('admin'):
            return redirect('/login')
        conn = get_db_connection()
        if conn is None:
            return "Error de conexión con la base de datos"
        
        conn.execute("DELETE FROM doctores WHERE id=?", (id,))
        conn.commit()
        conn.close()
        return redirect('/admin')
    except Exception as e:
        print(f"Error al eliminar doctor: {e}")
        return "Error al eliminar el doctor"

@admin_bp.route('/ver_citas')
def ver_citas():
    try:
        conn = get_db_connection()
        if conn is None:
            return "Error de conexión con la base de datos"
        
        citas = conn.execute('''SELECT citas.id, paciente, fecha, hora, doctores.nombre, doctores.especialidad, estado
                                 FROM citas JOIN doctores ON citas.doctor_id = doctores.id''').fetchall()
        conn.close()
        return render_template('ver_citas.html', citas=citas)
    except Exception as e:
        print(f"Error al ver citas: {e}")
        return "Error al cargar las citas"

@admin_bp.route('/concluir_cita/<int:cita_id>', methods=['GET', 'POST'])
def concluir_cita(cita_id):
    try:
        if request.method == 'POST':
            diagnostico = request.form.get('diagnostico', '')
            receta = request.form.get('receta', '')
            
            conn = get_db_connection()
            if conn is None:
                return "Error de conexión con la base de datos"
            
            conn.execute("UPDATE citas SET estado='concluida', diagnostico=?, receta=? WHERE id=?", 
                        (diagnostico, receta, cita_id))
            conn.commit()
            conn.close()
            return redirect('/ver_citas')
        else:
            # Si es GET, redirigir a la página de detalle para ingresar diagnóstico y receta
            return redirect(f'/cita_detalle/{cita_id}')
    except Exception as e:
        print(f"Error al concluir cita: {e}")
        return "Error al concluir la cita"

@admin_bp.route('/anular_cita/<int:cita_id>')
def anular_cita(cita_id):
    try:
        conn = get_db_connection()
        if conn is None:
            return "Error de conexión con la base de datos"
        
        conn.execute("UPDATE citas SET estado='anulado' WHERE id=?", (cita_id,))
        conn.commit()
        conn.close()
        return redirect('/ver_citas')
    except Exception as e:
        print(f"Error al anular cita: {e}")
        return "Error al anular la cita" 