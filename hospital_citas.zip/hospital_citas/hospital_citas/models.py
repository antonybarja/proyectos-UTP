try:
    import sqlite3
except ImportError as e:
    print(f"Error al importar sqlite3: {e}")
    print("Asegúrate de tener sqlite3 instalado")
    raise
except Exception as e:
    print(f"Error inesperado al importar en models.py: {e}")
    raise

def get_db_connection():
    try:
        conn = sqlite3.connect('database.db')
        conn.row_factory = sqlite3.Row
        return conn
    except sqlite3.Error as e:
        print(f"Error al conectar con la base de datos: {e}")
        return None

def init_db():
    try:
        conn = get_db_connection()
        if conn is None:
            print("No se pudo conectar con la base de datos")
            return
        
        cursor = conn.cursor()
        cursor.execute('''CREATE TABLE IF NOT EXISTS administradores (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            usuario TEXT NOT NULL,
            contrasena TEXT NOT NULL
        )''')
        cursor.execute('''CREATE TABLE IF NOT EXISTS doctores (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT NOT NULL,
            especialidad TEXT NOT NULL,
            sector TEXT NOT NULL,
            horario TEXT NOT NULL
        )''')
        cursor.execute('''CREATE TABLE IF NOT EXISTS citas (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            paciente TEXT NOT NULL,
            fecha TEXT NOT NULL,
            hora TEXT NOT NULL,
            doctor_id INTEGER,
            email TEXT,
            estado TEXT DEFAULT 'pendiente',
            diagnostico TEXT,
            receta TEXT,
            FOREIGN KEY(doctor_id) REFERENCES doctores(id)
        )''')
        if not cursor.execute("SELECT * FROM administradores").fetchone():
            cursor.execute("INSERT INTO administradores (usuario, contrasena) VALUES (?, ?)", ('admin', 'admin123'))
        conn.commit()
        conn.close()
        print("Base de datos inicializada correctamente")
    except sqlite3.Error as e:
        print(f"Error al inicializar la base de datos: {e}")
    except Exception as e:
        print(f"Error inesperado al inicializar la base de datos: {e}") 