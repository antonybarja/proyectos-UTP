try:
    import re
    from datetime import datetime
    from email.mime.text import MIMEText
    from email.mime.multipart import MIMEMultipart
except ImportError as e:
    print(f"Error al importar módulos de utilidades: {e}")
    raise
except Exception as e:
    print(f"Error inesperado en utilidades: {e}")
    raise

def validate_email(email):
    """Valida formato de email con manejo de excepciones"""
    try:
        if not email:
            return False
        pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        return re.match(pattern, email) is not None
    except Exception as e:
        print(f"Error al validar email: {e}")
        return False

def validate_date(date_str):
    """Valida formato de fecha con manejo de excepciones"""
    try:
        if not date_str:
            return False
        datetime.strptime(date_str, '%Y-%m-%d')
        return True
    except ValueError:
        return False
    except Exception as e:
        print(f"Error al validar fecha: {e}")
        return False

def validate_time(time_str):
    """Valida formato de hora con manejo de excepciones"""
    try:
        if not time_str:
            return False
        datetime.strptime(time_str, '%H:%M')
        return True
    except ValueError:
        return False
    except Exception as e:
        print(f"Error al validar hora: {e}")
        return False

def sanitize_input(text):
    """Sanitiza entrada de texto con manejo de excepciones"""
    try:
        if not text:
            return ""
        # Remover caracteres peligrosos
        sanitized = re.sub(r'[<>"\']', '', str(text))
        return sanitized.strip()
    except Exception as e:
        print(f"Error al sanitizar entrada: {e}")
        return ""

def format_datetime(date_str, time_str):
    """Formatea fecha y hora con manejo de excepciones"""
    try:
        if not date_str or not time_str:
            return None
        datetime_str = f"{date_str} {time_str}"
        return datetime.strptime(datetime_str, '%Y-%m-%d %H:%M')
    except ValueError:
        return None
    except Exception as e:
        print(f"Error al formatear fecha/hora: {e}")
        return None

def create_email_message(to_email, subject, body):
    """Crea mensaje de email con manejo de excepciones"""
    try:
        msg = MIMEMultipart()
        msg['From'] = 'fabrize18lion@gmail.com'
        msg['To'] = to_email
        msg['Subject'] = subject
        
        msg.attach(MIMEText(body, 'plain'))
        return msg
    except Exception as e:
        print(f"Error al crear mensaje de email: {e}")
        return None

def log_error(error_message, error_type="ERROR"):
    """Registra errores con manejo de excepciones"""
    try:
        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        log_entry = f"[{timestamp}] {error_type}: {error_message}\n"
        
        with open('hospital_app.log', 'a', encoding='utf-8') as log_file:
            log_file.write(log_entry)
    except Exception as e:
        print(f"Error al escribir en log: {e}")
        print(f"Error original: {error_message}") 