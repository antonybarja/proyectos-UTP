try:
    from flask import Flask
    from models import init_db
    from routes import main_bp, admin_bp
except ImportError as e:
    print(f"Error al importar módulos: {e}")
    print("Asegúrate de tener todas las dependencias instaladas")
    exit(1)
except Exception as e:
    print(f"Error inesperado al importar: {e}")
    exit(1)

app = Flask(__name__)
app.secret_key = 'clave_secreta_para_sesiones'

# Registrar blueprints
try:
    app.register_blueprint(main_bp)
    app.register_blueprint(admin_bp)
except Exception as e:
    print(f"Error al registrar blueprints: {e}")
    exit(1)

if __name__ == '__main__':
    try:
        print("Iniciando aplicación de gestión hospitalaria...")
        init_db()
        print("Base de datos inicializada correctamente")
        app.run(debug=True)
    except Exception as e:
        print(f"Error crítico al iniciar la aplicación: {e}")
        print("La aplicación no pudo iniciarse correctamente")