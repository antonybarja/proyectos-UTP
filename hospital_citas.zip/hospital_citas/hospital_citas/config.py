try:
    import os
    from datetime import datetime
except ImportError as e:
    print(f"Error al importar módulos de configuración: {e}")
    raise
except Exception as e:
    print(f"Error inesperado en configuración: {e}")
    raise

# Configuración de la aplicación
class Config:
    try:
        SECRET_KEY = 'clave_secreta_para_sesiones'
        DATABASE = 'database.db'
        DEBUG = True
        
        # Configuración de email
        EMAIL_HOST = 'smtp.gmail.com'
        EMAIL_PORT = 465
        EMAIL_USER = 'fabrize18lion@gmail.com'
        EMAIL_PASSWORD = 'iuci qioo zgfe ugxp'
        
        # Configuración de logging
        LOG_FILE = 'hospital_app.log'
        LOG_LEVEL = 'INFO'
        
    except Exception as e:
        print(f"Error al cargar configuración: {e}")
        raise

def get_config():
    try:
        return Config()
    except Exception as e:
        print(f"Error al obtener configuración: {e}")
        return None

def validate_config():
    try:
        config = get_config()
        if config is None:
            return False
        
        # Validar que los archivos necesarios existen
        if not os.path.exists(config.DATABASE):
            print(f"Base de datos no encontrada: {config.DATABASE}")
            return False
        
        return True
    except Exception as e:
        print(f"Error al validar configuración: {e}")
        return False 