package controlador;

import conexion.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import modelo.NodoUsuario;
import modelo.Usuario;

public class Ctrl_Usuario {
    private NodoUsuario raiz;
    private Map<Integer, Usuario> tablaHash;

    public Ctrl_Usuario() {
        this.raiz = null; // Inicializamos la raíz del árbol binario como nula
        this.tablaHash = new HashMap<>(); // Inicializamos la tabla hash
    }

    /**
     * Método para insertar un nuevo usuario en el árbol binario
     */
    public void insertar(Usuario objeto) {
        NodoUsuario nuevoNodo = new NodoUsuario(objeto);
        if (raiz == null) {
            raiz = nuevoNodo;
        } else {
            insertarRec(raiz, nuevoNodo);
        }
    }

    /**
     * Método auxiliar para insertar recursivamente en el árbol binario
     */
    private void insertarRec(NodoUsuario raizActual, NodoUsuario nuevoNodo) {
        if (nuevoNodo.getUsuario().getIdUsuario() < raizActual.getUsuario().getIdUsuario()) {
            if (raizActual.getLeft() == null) {
                raizActual.setLeft(nuevoNodo);
            } else {
                insertarRec(raizActual.getLeft(), nuevoNodo);
            }
        } else {
            if (raizActual.getRight() == null) {
                raizActual.setRight(nuevoNodo);
            } else {
                insertarRec(raizActual.getRight(), nuevoNodo);
            }
        }
    }

    /**
     * Método para guardar un nuevo usuario en la base de datos y en el árbol binario
     */
    public boolean guardar(Usuario objeto) {
        boolean respuesta = false;
        Connection cn = Conexion.conectar();
        try {
            PreparedStatement consulta = cn.prepareStatement("insert into tb_usuario values(?,?,?,?,?,?,?)");
            consulta.setInt(1, 0);//id
            consulta.setString(2, objeto.getNombre());
            consulta.setString(3, objeto.getApellido());
            consulta.setString(4, objeto.getUsuario());
            consulta.setString(5, objeto.getPassword());
            consulta.setString(6, objeto.getTelefono());
            consulta.setInt(7, objeto.getEstado());

            if (consulta.executeUpdate() > 0) {
                // Si se guarda correctamente en la base de datos, también insertamos en el árbol binario
                insertar(objeto);
                tablaHash.put(objeto.getIdUsuario(), objeto); // Insertamos en la tabla hash
                respuesta = true;
            }

            cn.close();

        } catch (SQLException e) {
            System.out.println("Error al guardar usuario: " + e);
        }

        return respuesta;
    }

    /**
     * Método para actualizar un usuario en la base de datos y en el árbol binario
     */
    public boolean actualizar(Usuario objeto, int idUsuario) {
        boolean respuesta = false;
        Connection cn = Conexion.conectar();
        try {
            PreparedStatement consulta = cn.prepareStatement("update tb_usuario set nombre=?, apellido = ?, usuario = ?, password= ?, telefono = ?, estado = ? where idUsuario = ?");
            consulta.setString(1, objeto.getNombre());
            consulta.setString(2, objeto.getApellido());
            consulta.setString(3, objeto.getUsuario());
            consulta.setString(4, objeto.getPassword());
            consulta.setString(5, objeto.getTelefono());
            consulta.setInt(6, objeto.getEstado());
            consulta.setInt(7, idUsuario);

            if (consulta.executeUpdate() > 0) {
                // Si se actualiza correctamente en la base de datos, también actualizamos en el árbol binario
                actualizarRec(raiz, objeto, idUsuario);
                tablaHash.put(idUsuario, objeto); // Actualizamos en la tabla hash
                respuesta = true;
            }
            cn.close();
        } catch (SQLException e) {
            System.out.println("Error al actualizar usuario: " + e);
        }
        return respuesta;
    }

    /**
     * Método auxiliar para actualizar recursivamente en el árbol binario
     */
    private void actualizarRec(NodoUsuario nodo, Usuario objeto, int idUsuario) {
        if (nodo != null) {
            if (nodo.getUsuario().getIdUsuario() == idUsuario) {
                nodo.setUsuario(objeto);
            } else {
                actualizarRec(nodo.getLeft(), objeto, idUsuario);
                actualizarRec(nodo.getRight(), objeto, idUsuario);
            }
        }
    }

    /**
     * Método para eliminar un usuario de la base de datos y del árbol binario
     */
    public boolean eliminar(int idUsuario) {
        boolean respuesta = false;
        Connection cn = Conexion.conectar();
        try {
            PreparedStatement consulta = cn.prepareStatement("delete from tb_usuario where idUsuario = ?");
            consulta.setInt(1, idUsuario);

            if (consulta.executeUpdate() > 0) {
                // Si se elimina correctamente en la base de datos, también eliminamos del árbol binario
                raiz = eliminarRec(raiz, idUsuario);
                tablaHash.remove(idUsuario); // Eliminamos de la tabla hash
                respuesta = true;
            }
            cn.close();
        } catch (SQLException e) {
            System.out.println("Error al eliminar usuario: " + e);
        }
        return respuesta;
    }

    /**
     * Método auxiliar para eliminar recursivamente del árbol binario
     */
    private NodoUsuario eliminarRec(NodoUsuario nodo, int idUsuario) {
        if (nodo == null) {
            return null;
        }

        if (idUsuario < nodo.getUsuario().getIdUsuario()) {
            nodo.setLeft(eliminarRec(nodo.getLeft(), idUsuario));
        } else if (idUsuario > nodo.getUsuario().getIdUsuario()) {
            nodo.setRight(eliminarRec(nodo.getRight(), idUsuario));
        } else {
            // Caso 1: Nodo sin hijos o con un hijo
            if (nodo.getLeft() == null) {
                return nodo.getRight();
            } else if (nodo.getRight() == null) {
                return nodo.getLeft();
            }

            // Caso 2: Nodo con dos hijos
            NodoUsuario sucesor = encontrarSucesor(nodo.getRight());
            nodo.setUsuario(sucesor.getUsuario());
            nodo.setRight(eliminarRec(nodo.getRight(), sucesor.getUsuario().getIdUsuario()));
        }
        return nodo;
    }

    /**
     * Método auxiliar para encontrar el sucesor en el árbol binario
     */
    private NodoUsuario encontrarSucesor(NodoUsuario nodo) {
        NodoUsuario actual = nodo;
        while (actual.getLeft() != null) {
            actual = actual.getLeft();
        }
        return actual;
    }

    /**
     * Método para consultar si el usuario ya está registrado en la base de datos
     */
    public boolean existeUsuario(String usuario) {
        boolean respuesta = false;
        String sql = "select usuario from tb_usuario where usuario = ?";
        try (Connection cn = Conexion.conectar();
             PreparedStatement consulta = cn.prepareStatement(sql)) {
            consulta.setString(1, usuario);
            ResultSet rs = consulta.executeQuery();
            if (rs.next()) {
                respuesta = true;
            }
        } catch (SQLException e) {
            System.out.println("Error al consultar usuario: " + e);
        }
        return respuesta;
    }

    /**
     * Método para iniciar sesión con un usuario
     */
    public boolean loginUser(Usuario usuario) {
        boolean loginExitoso = false;
        Connection cn = Conexion.conectar();
        String sql = "SELECT * FROM tb_usuario WHERE usuario = ? AND password = ?";

        try (PreparedStatement consulta = cn.prepareStatement(sql)) {
            consulta.setString(1, usuario.getUsuario());
            consulta.setString(2, usuario.getPassword());

            ResultSet rs = consulta.executeQuery();
            if (rs.next()) {
                // Si encontramos al menos un resultado, el login es exitoso
                loginExitoso = true;
            }
        } catch (SQLException e) {
            System.out.println("Error al intentar iniciar sesión: " + e);
        } finally {
            try {
                cn.close();
            } catch (SQLException ex) {
                System.out.println("Error al cerrar conexión: " + ex);
            }
        }

        return loginExitoso;
    }

    /**
     * Método para buscar un usuario por ID en la tabla hash
     */
    public Usuario buscarPorId(int idUsuario) {
        return tablaHash.get(idUsuario);
    }

    /**
     * Método para buscar un usuario por nombre de usuario en la tabla hash
     */
    public Usuario buscarPorNombreUsuario(String nombreUsuario) {
        for (Usuario usuario : tablaHash.values()) {
            if (usuario.getUsuario().equals(nombreUsuario)) {
                return usuario;
            }
        }
        return null;
    }
}
