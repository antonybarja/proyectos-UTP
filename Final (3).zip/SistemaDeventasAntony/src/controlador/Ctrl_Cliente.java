package controlador;

import conexion.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import modelo.Cliente;
import java.sql.Statement;
import modelo.NodoCliente;

public class Ctrl_Cliente {
    private NodoCliente raiz;

    public Ctrl_Cliente() {
        this.raiz = null;
        cargarClientesDesdeBaseDeDatos();
    }

    private void cargarClientesDesdeBaseDeDatos() {
        String sql = "SELECT * FROM tb_cliente";
        try (Connection cn = Conexion.conectar();
             Statement st = cn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                Cliente cliente = new Cliente(
                    rs.getInt("idCliente"),
                    rs.getString("nombre"),
                    rs.getString("apellido"),
                    rs.getString("cedula"),
                    rs.getString("telefono"),
                    rs.getString("direccion"),
                    rs.getInt("estado")
                );
                insertar(cliente);
            }
        } catch (SQLException e) {
            System.out.println("Error al cargar clientes: " + e);
        }
    }

    public boolean guardar(Cliente cliente) {
        boolean respuesta = false;
        Connection cn = Conexion.conectar();
        try {
            String sql = "INSERT INTO tb_cliente(nombre, apellido, cedula, telefono, direccion, estado) VALUES(?, ?, ?, ?, ?, ?)";
            PreparedStatement consulta = cn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            consulta.setString(1, cliente.getNombre());
            consulta.setString(2, cliente.getApellido());
            consulta.setString(3, cliente.getCedula());
            consulta.setString(4, cliente.getTelefono());
            consulta.setString(5, cliente.getDireccion());
            consulta.setInt(6, cliente.getEstado());

            if (consulta.executeUpdate() > 0) {
                ResultSet generatedKeys = consulta.getGeneratedKeys();
                if (generatedKeys.next()) {
                    cliente.setIdCliente(generatedKeys.getInt(1));
                }
                insertar(cliente);
                respuesta = true;
            }
        } catch (SQLException e) {
            System.out.println("Error al guardar cliente: " + e);
        }
        return respuesta;
    }

    public List<Cliente> buscarClienteDFS(String textoBusqueda) {
        List<Cliente> resultados = new ArrayList<>();
        buscarClienteDFSRec(raiz, textoBusqueda, resultados);
        return resultados;
    }

    private void buscarClienteDFSRec(NodoCliente nodo, String textoBusqueda, List<Cliente> resultados) {
        if (nodo != null) {
            Cliente cliente = nodo.getCliente();
            if (cliente.getNombre().toLowerCase().contains(textoBusqueda.toLowerCase()) ||
                cliente.getApellido().toLowerCase().contains(textoBusqueda.toLowerCase()) ||
                cliente.getCedula().toLowerCase().contains(textoBusqueda.toLowerCase()) ||
                cliente.getTelefono().toLowerCase().contains(textoBusqueda.toLowerCase()) ||
                cliente.getDireccion().toLowerCase().contains(textoBusqueda.toLowerCase())) {
                resultados.add(cliente);
            }
            buscarClienteDFSRec(nodo.getLeft(), textoBusqueda, resultados);
            buscarClienteDFSRec(nodo.getRight(), textoBusqueda, resultados);
        }
    }

    private void insertar(Cliente cliente) {
        NodoCliente nuevoNodo = new NodoCliente(cliente);
        if (raiz == null) {
            raiz = nuevoNodo;
        } else {
            insertarRec(raiz, nuevoNodo);
        }
    }

    private void insertarRec(NodoCliente raizActual, NodoCliente nuevoNodo) {
        if (nuevoNodo.getCliente().getIdCliente() < raizActual.getCliente().getIdCliente()) {
            if (raizActual.getLeft() == null) {
                raizActual.setLeft(nuevoNodo);
            } else {
                insertarRec(raizActual.getLeft(), nuevoNodo);
            }
        } else {
            if (raizActual.getRight() == null) {
                raizActual.setRight(nuevoNodo);
            } else {
                insertarRec(raizActual.getRight(), nuevoNodo);
            }
        }
    }

    public boolean existeCliente(String cedula) {
        boolean respuesta = false;
        String sql = "SELECT cedula FROM tb_cliente WHERE cedula = ?";
        try (Connection cn = Conexion.conectar();
             PreparedStatement st = cn.prepareStatement(sql)) {
            st.setString(1, cedula);
            ResultSet rs = st.executeQuery();
            if (rs.next()) {
                respuesta = true;
            }
        } catch (SQLException e) {
            System.out.println("Error al consultar cliente: " + e);
        }
        return respuesta;
    }

    public boolean actualizar(Cliente cliente) {
        boolean respuesta = false;
        Connection cn = Conexion.conectar();
        try {
            String sql = "UPDATE tb_cliente SET nombre = ?, apellido = ?, cedula = ?, telefono = ?, direccion = ?, estado = ? WHERE idCliente = ?";
            PreparedStatement consulta = cn.prepareStatement(sql);
            consulta.setString(1, cliente.getNombre());
            consulta.setString(2, cliente.getApellido());
            consulta.setString(3, cliente.getCedula());
            consulta.setString(4, cliente.getTelefono());
            consulta.setString(5, cliente.getDireccion());
            consulta.setInt(6, cliente.getEstado());
            consulta.setInt(7, cliente.getIdCliente());

            if (consulta.executeUpdate() > 0) {
                actualizarRec(raiz, cliente);
                respuesta = true;
            }
        } catch (SQLException e) {
            System.out.println("Error al actualizar cliente: " + e);
        }
        return respuesta;
    }

    private void actualizarRec(NodoCliente nodo, Cliente cliente) {
        if (nodo != null) {
            if (nodo.getCliente().getIdCliente() == cliente.getIdCliente()) {
                nodo.setCliente(cliente);
            } else {
                actualizarRec(nodo.getLeft(), cliente);
                actualizarRec(nodo.getRight(), cliente);
            }
        }
    }

    public boolean eliminar(int idCliente) {
        boolean respuesta = false;
        Connection cn = Conexion.conectar();
        try {
            String sql = "DELETE FROM tb_cliente WHERE idCliente = ?";
            PreparedStatement consulta = cn.prepareStatement(sql);
            consulta.setInt(1, idCliente);

            if (consulta.executeUpdate() > 0) {
                raiz = eliminarRec(raiz, idCliente);
                respuesta = true;
            }
        } catch (SQLException e) {
            System.out.println("Error al eliminar cliente: " + e);
        }
        return respuesta;
    }

    private NodoCliente eliminarRec(NodoCliente nodo, int idCliente) {
        if (nodo == null) {
            return null;
        }

        if (idCliente < nodo.getCliente().getIdCliente()) {
            nodo.setLeft(eliminarRec(nodo.getLeft(), idCliente));
        } else if (idCliente > nodo.getCliente().getIdCliente()) {
            nodo.setRight(eliminarRec(nodo.getRight(), idCliente));
        } else {
            if (nodo.getLeft() == null) {
                return nodo.getRight();
            } else if (nodo.getRight() == null) {
                return nodo.getLeft();
            }

            NodoCliente sucesor = encontrarSucesor(nodo.getRight());
            nodo.setCliente(sucesor.getCliente());
            nodo.setRight(eliminarRec(nodo.getRight(), sucesor.getCliente().getIdCliente()));
        }
        return nodo;
    }

    private NodoCliente encontrarSucesor(NodoCliente nodo) {
        NodoCliente actual = nodo;
        while (actual.getLeft() != null) {
            actual = actual.getLeft();
        }
        return actual;
    }
}
