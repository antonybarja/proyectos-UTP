package controlador;

import conexion.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import modelo.Categoria;
import modelo.GrafoCategorias;
import modelo.NodoCategoria;

public class Ctrl_Categoria {

    private GrafoCategorias grafoCategorias;

    public Ctrl_Categoria() {
        this.grafoCategorias = new GrafoCategorias();
        cargarCategoriasEnGrafo();
    }

    private void cargarCategoriasEnGrafo() {
        String sql = "SELECT idCategoria, descripcion, estado FROM tb_categoria";
        try (Connection con = Conexion.conectar(); PreparedStatement pst = con.prepareStatement(sql); ResultSet rs = pst.executeQuery()) {
            while (rs.next()) {
                Categoria categoria = new Categoria(rs.getInt("idCategoria"), rs.getString("descripcion"), rs.getInt("estado"));
                grafoCategorias.agregarCategoria(categoria);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public boolean guardar(Categoria objeto) {
        boolean respuesta = false;
        String sql = "INSERT INTO tb_categoria (descripcion, estado) VALUES(?, ?)";
        try (Connection cn = Conexion.conectar(); PreparedStatement consulta = cn.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS)) {
            consulta.setString(1, objeto.getDescripcion());
            consulta.setInt(2, objeto.getEstado());

            if (consulta.executeUpdate() > 0) {
                // Obtener el id generado para la nueva categoría
                try (ResultSet rs = consulta.getGeneratedKeys()) {
                    if (rs.next()) {
                        int nuevoId = rs.getInt(1);
                        objeto.setIdCategoria(nuevoId);
                        grafoCategorias.agregarCategoria(objeto); // Actualizar el grafo
                        respuesta = true;
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return respuesta;
    }

    public boolean actualizar(Categoria objeto, int idCategoria) {
        boolean respuesta = false;
        String sql = "UPDATE tb_categoria SET descripcion = ?, estado = ? WHERE idCategoria = ?";
        try (Connection cn = Conexion.conectar(); PreparedStatement consulta = cn.prepareStatement(sql)) {
            consulta.setString(1, objeto.getDescripcion());
            consulta.setInt(2, objeto.getEstado());
            consulta.setInt(3, idCategoria);

            if (consulta.executeUpdate() > 0) {
                respuesta = true;
                NodoCategoria nodo = grafoCategorias.obtenerNodo(idCategoria);
                if (nodo != null) {
                    nodo.setCategoria(objeto); // Actualizar el nodo en el grafo
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return respuesta;
    }

    public boolean eliminar(int idCategoria) {
        boolean respuesta = false;
        String sql = "DELETE FROM tb_categoria WHERE idCategoria = ?";
        try (Connection cn = Conexion.conectar(); PreparedStatement consulta = cn.prepareStatement(sql)) {
            consulta.setInt(1, idCategoria);

            if (consulta.executeUpdate() > 0) {
                respuesta = true;
                // Eliminar el nodo y sus conexiones del grafo
                grafoCategorias.obtenerNodo(idCategoria);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return respuesta;
    }

    public void conectarCategorias(int idCategoria1, int idCategoria2) {
        grafoCategorias.conectarCategorias(idCategoria1, idCategoria2);
    }

    public void desconectarCategorias(int idCategoria1, int idCategoria2) {
        grafoCategorias.desconectarCategorias(idCategoria1, idCategoria2);
    }

    public boolean existeCategoria(String descripcion) {
        String sql = "SELECT COUNT(*) FROM tb_categoria WHERE descripcion = ?";
        try (Connection cn = Conexion.conectar(); PreparedStatement consulta = cn.prepareStatement(sql)) {
            consulta.setString(1, descripcion);
            try (ResultSet rs = consulta.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}
