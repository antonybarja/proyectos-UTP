package controlador;

import conexion.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import modelo.NodoProducto;
import modelo.Producto;

public class Ctrl_Producto {
    private NodoProducto raiz;
    private List<Producto> productos;

    public Ctrl_Producto() {
        this.raiz = null; // Inicializamos la raíz del árbol binario como nula
        productos = new ArrayList<>();
    }

    /**
     * Método para insertar un nuevo producto en el árbol binario
     */
    public void insertar(Producto objeto) {
        NodoProducto nuevoNodo = new NodoProducto(objeto);
        if (raiz == null) {
            raiz = nuevoNodo;
        } else {
            insertarRec(raiz, nuevoNodo);
        }
    }

    /**
     * Método auxiliar para insertar recursivamente en el árbol binario
     */
    private void insertarRec(NodoProducto raizActual, NodoProducto nuevoNodo) {
        if (nuevoNodo.getProducto().getIdProducto() < raizActual.getProducto().getIdProducto()) {
            if (raizActual.getLeft() == null) {
                raizActual.setLeft(nuevoNodo);
            } else {
                insertarRec(raizActual.getLeft(), nuevoNodo);
            }
        } else {
            if (raizActual.getRight() == null) {
                raizActual.setRight(nuevoNodo);
            } else {
                insertarRec(raizActual.getRight(), nuevoNodo);
            }
        }
    }

    /**
     * Método para recorrido inorder del árbol binario
     */
    public List<Producto> inorder() {
        productos.clear(); // Limpiamos la lista antes de agregar productos ordenados
        inorderRec(raiz);
        productos.sort((p1, p2) -> Integer.compare(p1.getIdProducto(), p2.getIdProducto()));
        return productos;
    }

    /**
     * Método auxiliar para recorrido inorder recursivo
     */
    private void inorderRec(NodoProducto nodo) {
        if (nodo != null) {
            inorderRec(nodo.getLeft());
            productos.add(nodo.getProducto());
            inorderRec(nodo.getRight());
        }
    }

    /**
     * Método para recorrido preorder del árbol binario
     */
    public List<Producto> preorder() {
        productos.clear(); // Limpiamos la lista antes de agregar productos ordenados
        preorderRec(raiz);
        productos.sort((p1, p2) -> Integer.compare(p1.getIdProducto(), p2.getIdProducto()));
        return productos;
    }

    /**
     * Método auxiliar para recorrido preorder recursivo
     */
    private void preorderRec(NodoProducto nodo) {
        if (nodo != null) {
            productos.add(nodo.getProducto());
            preorderRec(nodo.getLeft());
            preorderRec(nodo.getRight());
        }
    }

    /**
     * Método para recorrido postorder del árbol binario
     */
    public List<Producto> postorder() {
        productos.clear(); // Limpiamos la lista antes de agregar productos ordenados
        postorderRec(raiz);
        productos.sort((p1, p2) -> Integer.compare(p2.getIdProducto(), p1.getIdProducto()));
        return productos;
    }

    /**
     * Método auxiliar para recorrido postorder recursivo
     */
    private void postorderRec(NodoProducto nodo) {
        if (nodo != null) {
            postorderRec(nodo.getLeft());
            postorderRec(nodo.getRight());
            productos.add(nodo.getProducto());
        }
    }

    /**
     * Método para guardar un nuevo producto en la base de datos
     */
    public boolean guardar(Producto objeto) {
        boolean respuesta = false;
        Connection cn = Conexion.conectar();
        try {
            PreparedStatement consulta = cn.prepareStatement("insert into tb_producto values(?,?,?,?,?,?,?,?)");
            consulta.setInt(1, 0);//id
            consulta.setString(2, objeto.getNombre());
            consulta.setInt(3, objeto.getCantidad());
            consulta.setDouble(4, objeto.getPrecio());
            consulta.setString(5, objeto.getDescripcion());
            consulta.setInt(6, objeto.getPorcentajeIgv());
            consulta.setInt(7, objeto.getIdCategoria());
            consulta.setInt(8, objeto.getEstado());

            if (consulta.executeUpdate() > 0) {
                // Si se guarda correctamente en la base de datos, también insertamos en el árbol binario
                insertar(objeto);
                respuesta = true;
            }

            cn.close();

        } catch (SQLException e) {
            System.out.println("Error al guardar producto: " + e);
        }

        return respuesta;
    }

    /**
     * Método para actualizar un producto en la base de datos y en el árbol binario
     */
    public boolean actualizar(Producto objeto, int idProducto) {
        boolean respuesta = false;
        Connection cn = Conexion.conectar();
        try {
            PreparedStatement consulta = cn.prepareStatement("update tb_producto set nombre=?, cantidad = ?, precio = ?, descripcion= ?, porcentajeIgv = ?, idCategoria = ?, estado = ? where idProducto = ?");
            consulta.setString(1, objeto.getNombre());
            consulta.setInt(2, objeto.getCantidad());
            consulta.setDouble(3, objeto.getPrecio());
            consulta.setString(4, objeto.getDescripcion());
            consulta.setInt(5, objeto.getPorcentajeIgv());
            consulta.setInt(6, objeto.getIdCategoria());
            consulta.setInt(7, objeto.getEstado());
            consulta.setInt(8, idProducto);

            if (consulta.executeUpdate() > 0) {
                // Si se actualiza correctamente en la base de datos, también actualizamos en el árbol binario
                actualizarRec(raiz, objeto, idProducto);
                respuesta = true;
            }
            cn.close();
        } catch (SQLException e) {
            System.out.println("Error al actualizar producto: " + e);
        }
        return respuesta;
    }

    /**
     * Método auxiliar para actualizar recursivamente en el árbol binario
     */
    private void actualizarRec(NodoProducto nodo, Producto objeto, int idProducto) {
        if (nodo != null) {
            if (nodo.getProducto().getIdProducto() == idProducto) {
                nodo.setProducto(objeto);
            } else {
                actualizarRec(nodo.getLeft(), objeto, idProducto);
                actualizarRec(nodo.getRight(), objeto, idProducto);
            }
        }
    }

    /**
     * Método para eliminar un producto de la base de datos y del árbol binario
     */
    public boolean eliminar(int idProducto) {
        boolean respuesta = false;
        Connection cn = Conexion.conectar();
        try {
            PreparedStatement consulta = cn.prepareStatement("delete from tb_producto where idProducto = ?");
            consulta.setInt(1, idProducto);

            if (consulta.executeUpdate() > 0) {
                // Si se elimina correctamente en la base de datos, también eliminamos del árbol binario
                raiz = eliminarRec(raiz, idProducto);
                respuesta = true;
            }
            cn.close();
        } catch (SQLException e) {
            System.out.println("Error al eliminar producto: " + e);
        }
        return respuesta;
    }

    /**
     * Método auxiliar para eliminar recursivamente del árbol binario
     */
    private NodoProducto eliminarRec(NodoProducto nodo, int idProducto) {
        if (nodo == null) {
            return null;
        }

        if (idProducto < nodo.getProducto().getIdProducto()) {
            nodo.setLeft(eliminarRec(nodo.getLeft(), idProducto));
        } else if (idProducto > nodo.getProducto().getIdProducto()) {
            nodo.setRight(eliminarRec(nodo.getRight(), idProducto));
        } else {
            // Caso 1: Nodo sin hijos o con un hijo
            if (nodo.getLeft() == null) {
                return nodo.getRight();
            } else if (nodo.getRight() == null) {
                return nodo.getLeft();
            }

            // Caso 2: Nodo con dos hijos
            NodoProducto sucesor = encontrarSucesor(nodo.getRight());
            nodo.setProducto(sucesor.getProducto());
            nodo.setRight(eliminarRec(nodo.getRight(), sucesor.getProducto().getIdProducto()));
        }
        return nodo;
    }

    /**
     * Método auxiliar para encontrar el sucesor en el árbol binario
     */
    private NodoProducto encontrarSucesor(NodoProducto nodo) {
        NodoProducto actual = nodo;
        while (actual.getLeft() != null) {
            actual = actual.getLeft();
        }
        return actual;
    }

    /**
     * Método para actualizar el stock de un producto en la base de datos y en el árbol binario
     */
    public boolean actualizarStock(Producto objeto, int idProducto) {
        boolean respuesta = false;
        Connection cn = Conexion.conectar();
        try {
            PreparedStatement consulta = cn.prepareStatement("update tb_producto set cantidad=? where idProducto = ?");
            consulta.setInt(1, objeto.getCantidad());
            consulta.setInt(2, idProducto);

            if (consulta.executeUpdate() > 0) {
                // Si se actualiza correctamente en la base de datos, también actualizamos en el árbol binario
                actualizarStockRec(raiz, objeto, idProducto);
                respuesta = true;
            }
            cn.close();
        } catch (SQLException e) {
            System.out.println("Error al actualizar stock del producto: " + e);
        }
        return respuesta;
    }

    /**
     * Método auxiliar para actualizar el stock recursivamente en el árbol binario
     */
    private void actualizarStockRec(NodoProducto nodo, Producto objeto, int idProducto) {
        if (nodo != null) {
            if (nodo.getProducto().getIdProducto() == idProducto) {
                nodo.getProducto().setCantidad(objeto.getCantidad());
            }
            actualizarStockRec(nodo.getLeft(), objeto, idProducto);
            actualizarStockRec(nodo.getRight(), objeto, idProducto);
        }
    }

    /**
     * Método para consultar si el producto ya está registrado en la base de datos
     */
    public boolean existeProducto(String producto) {
        boolean respuesta = false;
        String sql = "select nombre from tb_producto where nombre = ?";
        try (Connection cn = Conexion.conectar();
             PreparedStatement st = cn.prepareStatement(sql)) {
            st.setString(1, producto);
            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                respuesta = true;
            }
        } catch (SQLException e) {
            System.out.println("Error al consultar producto: " + e);
        }
        return respuesta;
    }
    
    
}