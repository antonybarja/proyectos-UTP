package modelo; 

public class NodoProducto {
    private Producto producto;
    private NodoProducto left;
    private NodoProducto right;

    // Constructor
    public NodoProducto(Producto producto) {
        this.producto = producto;
        this.left = null;
        this.right = null;
    }

    // Getter y setter para los campos
    public Producto getProducto() {
        return producto;
    }

    public void setProducto(Producto producto) {
        this.producto = producto;
    }

    public NodoProducto getLeft() {
        return left;
    }

    public void setLeft(NodoProducto left) {
        this.left = left;
    }

    public NodoProducto getRight() {
        return right;
    }

    public void setRight(NodoProducto right) {
        this.right = right;
    }
}