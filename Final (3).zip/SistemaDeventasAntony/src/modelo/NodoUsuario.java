package modelo;

public class NodoUsuario {
    private Usuario usuario;     // Objeto Usuario almacenado en este nodo
    private NodoUsuario left;    // Referencia al nodo hijo izquierdo
    private NodoUsuario right;   // Referencia al nodo hijo derecho

    // Constructor
    public NodoUsuario(Usuario usuario) {
        this.usuario = usuario;  // Inicializa el usuario con el objeto pasado como parámetro
        this.left = null;        // Inicializa el hijo izquierdo como nulo
        this.right = null;       // Inicializa el hijo derecho como nulo
    }

    // Getter y setter para usuario
    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    // Getter y setter para el hijo izquierdo
    public NodoUsuario getLeft() {
        return left;
    }

    public void setLeft(NodoUsuario left) {
        this.left = left;
    }

    // Getter y setter para el hijo derecho
    public NodoUsuario getRight() {
        return right;
    }

    public void setRight(NodoUsuario right) {
        this.right = right;
    }
}
