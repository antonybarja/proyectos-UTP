package modelo;

import java.util.ArrayList;
import java.util.List;

public class NodoCategoria {
    private Categoria categoria;
    private List<NodoCategoria> conexiones;

    public NodoCategoria(Categoria categoria) {
        this.categoria = categoria;
        this.conexiones = new ArrayList<>();
    }

    public Categoria getCategoria() {
        return categoria;
    }

    public void setCategoria(Categoria categoria) {
        this.categoria = categoria;
    }

    public List<NodoCategoria> getConexiones() {
        return conexiones;
    }

    public void addConexion(NodoCategoria nodo) {
        if (!conexiones.contains(nodo)) {
            conexiones.add(nodo);
        }
    }

    public void removeConexion(NodoCategoria nodo) {
        conexiones.remove(nodo);
    }
}
