package modelo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class GrafosUsuario {
    private Map<Integer, List<Integer>> adjList;

    public GrafosUsuario() {
        this.adjList = new HashMap<>();
    }

    public void agregarRelacion(int usuario, int relacionadoCon) {
        this.adjList.putIfAbsent(usuario, new ArrayList<>());
        this.adjList.get(usuario).add(relacionadoCon);
    }

    public List<Integer> getRelaciones(int usuario) {
        return this.adjList.getOrDefault(usuario, new ArrayList<>());
    }
}


