package modelo;

import java.util.HashMap;
import java.util.Map;

public class GrafoCategorias {
    private Map<Integer, NodoCategoria> nodos;

    public GrafoCategorias() {
        this.nodos = new HashMap<>();
    }

    public void agregarCategoria(Categoria categoria) {
        if (!nodos.containsKey(categoria.getIdCategoria())) {
            NodoCategoria nuevoNodo = new NodoCategoria(categoria);
            nodos.put(categoria.getIdCategoria(), nuevoNodo);
        }
    }

    public void conectarCategorias(int idCategoria1, int idCategoria2) {
        NodoCategoria nodo1 = nodos.get(idCategoria1);
        NodoCategoria nodo2 = nodos.get(idCategoria2);
        if (nodo1 != null && nodo2 != null) {
            nodo1.addConexion(nodo2);
            nodo2.addConexion(nodo1); // Si el grafo es no dirigido
        }
    }

    public void desconectarCategorias(int idCategoria1, int idCategoria2) {
        NodoCategoria nodo1 = nodos.get(idCategoria1);
        NodoCategoria nodo2 = nodos.get(idCategoria2);
        if (nodo1 != null && nodo2 != null) {
            nodo1.removeConexion(nodo2);
            nodo2.removeConexion(nodo1); // Si el grafo es no dirigido
        }
    }

    public NodoCategoria obtenerNodo(int idCategoria) {
        return nodos.get(idCategoria);
    }
}
