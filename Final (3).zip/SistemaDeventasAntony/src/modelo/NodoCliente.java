package modelo;

public class NodoCliente {
    private Cliente cliente;
    private NodoCliente left;
    private NodoCliente right;

    // Constructor
    public NodoCliente(Cliente cliente) {
        this.cliente = cliente;
        this.left = null;
        this.right = null;
    }

    // Getter y setter para los campos
    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public NodoCliente getLeft() {
        return left;
    }

    public void setLeft(NodoCliente left) {
        this.left = left;
    }

    public NodoCliente getRight() {
        return right;
    }

    public void setRight(NodoCliente right) {
        this.right = right;
    }
}