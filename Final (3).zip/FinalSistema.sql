create database bd_sistema_ventas;

use bd_sistema_ventas;

select * from tb_producto;

select descripcion from tb_categoria where descripcion=' ';

truncate table tb_producto;

insert into tb_usuario(nombre, apellido, usuario, password, telefono, estado)
values("Alejandra","Carranza", "alejandra", "12345", "0987654321", 1);

select * from tb_producto;

select usuario, password from tb_usuario
 where usuario="alejandra" and password="12345";
-- tablausuarios

create table tb_usuario(
idUsuario int(11) auto_increment primary key,
nombre varchar(30) not null,
apellido varchar(30) not null,
usuario varchar(15) not null,
password varchar(15) not null,
telefono varchar(15) not null,
estado int(1) not null
);

show tables;

-- tabla categoria
create table tb_categoria(
idCategoria int(11) auto_increment primary key,
descripcion varchar(200) not null,
estado int(1) not null
);

-- tabla detalle de venta

create table tb_detalle_venta(
idDetalleVenta int(11) auto_increment primary key,
idCabeceraVenta int(11) not null,
idProducto int(11) not null,
cantidad int(11) not null,
precioUnitario double(10,2) not null,
subtotal double(10,2) not null,
descuento double(10,2) not null,
iva double(10,2) not null,
totalPagar double(10,2) not null,
estado int(1) not null
);

show tables;

select * from tb_producto;

ALTER TABLE tb_categoria
ADD COLUMN idCategoriaPadre INT;

ALTER TABLE tb_categoria
DROP COLUMN idCategoriaPadre;

ALTER TABLE tb_producto RENAME COLUMN porcentajeIva TO porcentajeIgv;


